package com.github.dawidd6.andttt.events;

public class ConnectFailEvent {
    public ConnectFailEvent() {
    }
}
