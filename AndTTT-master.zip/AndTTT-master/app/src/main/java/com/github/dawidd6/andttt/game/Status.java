package com.github.dawidd6.andttt.game;

public enum Status {
    PLAYING,
    WIN,
    DRAW,
}
