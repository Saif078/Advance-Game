package com.github.dawidd6.andttt.events;

public class DisconnectEvent {
    public DisconnectEvent() {
    }
}
