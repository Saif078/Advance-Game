package com.github.dawidd6.andttt.activities;

import android.os.Bundle;

import com.github.dawidd6.andttt.R;

public class MainActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
